document.addEventListener("DOMContentLoaded", function() {
  document.getElementById('generateBubble').addEventListener('click', createBubble);
});

function createBubble() {
  const bubble = document.createElement('div');
  bubble.classList.add('bubble');
  bubble.style.width = bubble.style.height = `${Math.random() * 100 + 20}px`;
  bubble.style.left = `${Math.random() * window.innerWidth}px`;
  bubble.style.bottom = '0px';

bubble.addEventListener('click',function(){
  bubble.remove();
});
  
  document.body.appendChild(bubble);

  let bottom = 0;
  const interval = setInterval(() => {
    bottom += 2;
    bubble.style.bottom = `${bottom}px`;

    if (bottom > window.innerHeight) {
      clearInterval(interval);
      bubble.remove();
    }
  }, 20);
}